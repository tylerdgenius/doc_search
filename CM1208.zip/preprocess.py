def preprocess_text(text):
    return text.split()
